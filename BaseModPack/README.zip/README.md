This is the baseline of mods my group use. The purpose is to make moving around and trying other mod packs easier.
