1.1.0 - Add LateCompany

1.2.0 - Add MoreCompany

1.2.1 - Update Git URL

1.3.0 - Add BatTeam-LethalFashion

2.0.0

```
LethalResonance-LETHALRESONANCE
x753-Mimics
mrov-TerminalFormatter
ButteryStancakes-MeleeFixes
Dev1A3-LethalFixes
mattymatty-Matty_Fixes
taffyko-BetterSprayPaint
FutureSavior-Hold_Scan_Button
Confusified-InsanityDisplay
PXC-ShipLootPlus
readboy_and_the_boys-brackensuit-1.0.2
Dwarggo-Fashion_Company-1.3.1
```

3.0.0

```
Piggy-LC_Office-1.1.29
skidz-PoolRooms-0.1.22
fumiko-CullFactory-1.1.2
Zaggy1024-PathfindingLagFix-1.2.1
Electric131-OuijaBoard-1.5.3
Fredolx-MeteoMultiplier-1.1.3
```
